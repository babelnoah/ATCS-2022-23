"""
Our main application logic
"""

from database import init_db, db_session
from models import *
from sqlalchemy import func

# Initialize our database
init_db()


print("\nQuery 1: ")


print("\nQuery 2: ")


print("\nQuery 3: ")


print("\nQuery 4: ")


print("\nQuery 5: ")


# Remove the session at the very end
db_session.remove()
